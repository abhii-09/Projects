# WebGL Distortion Slider

A Pen created on CodePen.io. Original URL: [https://codepen.io/ashthornton/pen/KRQbMO](https://codepen.io/ashthornton/pen/KRQbMO).

<a href="https://dribbble.com/shots/4537300-WWF-Header-Transition">My recreation of this Dribbble shot</a>

Using Three.js for the image transitions and some crude HTML + CSS just to mockup the UI around the background.

Credit to <a href="http://robindelaporte.fr/">Robin Delaporte</a> for the beginnings of this concept: https://tympanus.net/codrops/2018/04/10/webgl-distortion-hover-effects/